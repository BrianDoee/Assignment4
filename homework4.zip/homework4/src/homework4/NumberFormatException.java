package homework4;

public class NumberFormatException extends Exception {

}
