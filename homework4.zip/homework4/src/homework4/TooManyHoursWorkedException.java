package homework4;

public class TooManyHoursWorkedException extends Exception {

}
